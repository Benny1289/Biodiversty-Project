package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Image;
import com.google.appinventor.components.runtime.TableArrangement;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Label;
class Screen3 extends Form implements HandlesEventDispatching {
  private Image Image1;
  private TableArrangement TableArrangement1;
  private Button Button1;
  private Button Button2;
  private Label Label1;
  protected void $define() {
    this.AppName("BioDiversty");
    this.Scrollable(true);
    this.Title("Screen3");
    Image1 = new Image(this);
    Image1.Height(300);
    Image1.Width(LENGTH_FILL_PARENT);
    Image1.Picture("Panda2.JPG");
    TableArrangement1 = new TableArrangement(this);
    TableArrangement1.Columns(3);
    TableArrangement1.Height(LENGTH_FILL_PARENT);
    TableArrangement1.Width(LENGTH_FILL_PARENT);
    TableArrangement1.Rows(1);
    Button1 = new Button(TableArrangement1);
    Button1.Column(0);
    Button1.Row(0);
    Button1.Text("Main Menu");
    Button2 = new Button(TableArrangement1);
    Button2.Column(2);
    Button2.Row(0);
    Button2.Text("Animal Facts");
    Label1 = new Label(TableArrangement1);
    Label1.Column(1);
    Label1.Row(0);
    Label1.Text("You finished the Quiz!");
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    return false;
  }
}