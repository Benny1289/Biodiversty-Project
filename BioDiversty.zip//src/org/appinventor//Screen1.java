package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Image;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Button;
class Screen1 extends Form implements HandlesEventDispatching {
  private Image Image1;
  private Label Label1;
  private HorizontalArrangement HorizontalArrangement1;
  private Button Start_Quiz;
  private Button See_animals;
  private Button Sources;
  protected void $define() {
    this.AppName("BioDiversty");
    this.Title("Home");
    Image1 = new Image(this);
    Image1.Height(200);
    Image1.Width(310);
    Image1.Picture("Narwal.jpg");
    Label1 = new Label(this);
    Label1.Text("Welcome to the biodiversity quiz and facts app! This app will help you learn about different animals and and facts about them. This is a WIP app so there is more to be added!");
    HorizontalArrangement1 = new HorizontalArrangement(this);
    HorizontalArrangement1.Width(LENGTH_FILL_PARENT);
    Start_Quiz = new Button(HorizontalArrangement1);
    Start_Quiz.Width(LENGTH_FILL_PARENT);
    Start_Quiz.Text("Start Quiz");
    See_animals = new Button(HorizontalArrangement1);
    See_animals.Width(LENGTH_FILL_PARENT);
    See_animals.Text("See Animal Info");
    Sources = new Button(this);
    Sources.Width(LENGTH_FILL_PARENT);
    Sources.Text("Sources");
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    return false;
  }
}