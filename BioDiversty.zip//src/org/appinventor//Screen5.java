package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Label;
class Screen5 extends Form implements HandlesEventDispatching {
  private Button Button1;
  private Label Label1;
  private Label Label2;
  private Label Label3;
  private Label Label4;
  private Label Label5;
  private Label Label6;
  private Label Label7;
  private Label Label8;
  private Label Label9;
  private Label Label10;
  private Button Button2;
  protected void $define() {
    this.AppName("BioDiversty");
    this.Scrollable(true);
    this.Title("Screen5");
    Button1 = new Button(this);
    Button1.Width(LENGTH_FILL_PARENT);
    Button1.Text("Main Menu");
    Label1 = new Label(this);
    Label1.Text("Abernethy, J. (2017, June 22). Great White Shark. Retrieved June 5, 2018, from https://www.nationalgeographic.com/animals/fish/g/great-white-shark/");
    Label2 = new Label(this);
    Label2.Text("African Elephant. (2017, November 11). Retrieved June 5, 2018, from https://www.nationalgeographic.com/animals/mammals/a/african-elephant/");
    Label3 = new Label(this);
    Label3.Text("Emperor Penguin. (2014, April 01). Retrieved from https://kids.nationalgeographic.com/animals/emperor-penguin/#emperor-penguin-group-snow.jpg");
    Label4 = new Label(this);
    Label4.Text("Giant Panda. (2017, October 24). Retrieved June 5, 2018, from https://www.nationalgeographic.com/animals/mammals/g/giant-panda/");
    Label5 = new Label(this);
    Label5.Text("Gray Wolf. (2010, September 10). Retrieved June 5, 2018, from https://www.nationalgeographic.com/animals/mammals/g/gray-wolf/");
    Label6 = new Label(this);
    Label6.Text("Polar Bear Profile With Pictures, Facts and Map. (2014, March 26). Retrieved from https://kids.nationalgeographic.com/animals/polar-bear/?_ga=2.255216264.1028462026.1528244596-967276148.1528244596#polar-bear-cub-on-mom.jpg");
    Label7 = new Label(this);
    Label7.Text("Robbins, M. (2010, September 10). Mountain Gorilla. Retrieved June 5, 2018, from https://www.nationalgeographic.com/animals/mammals/m/mountain-gorilla/");
    Label8 = new Label(this);
    Label8.Text("Tiger. (2014, April 02). Retrieved from https://kids.nationalgeographic.com/animals/tiger/#ww-wild-cats-tiger.jpg");
    Label9 = new Label(this);
    Label9.Text("Unbelievably Cute Mammal With Teddy Bear Face Rediscovered. (2015, March 19). Retrieved June 5, 2018, from https://news.nationalgeographic.com/2015/03/150319-china-ili-pika-animals-conservation-science-rare-species/");
    Label10 = new Label(this);
    Label10.Text("Unicorn of the Sea: Narwhal Facts. (n.d.). Retrieved June 5, 2018, from https://www.worldwildlife.org/stories/unicorn-of-the-sea-narwhal-facts ");
    Button2 = new Button(this);
    Button2.Width(LENGTH_FILL_PARENT);
    Button2.Text("Main Menu");
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    return false;
  }
}